package com.javaproject.util;


import java.util.Properties;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;
import com.javaproject.model.HotelManagement;

public class HibernateUtil 
{
	private static SessionFactory sessionFactory;
	public static SessionFactory getSessionFactory() {
		if(sessionFactory == null)
		{
			try
			{
				Configuration config=new Configuration();
				Properties settings = new Properties();
				settings.put(Environment.DRIVER,"com.mysql.cj.jdbc.Driver");
				settings.put(Environment.URL,"jdbc:mysql://localhost:3306/anudip?useSSl=false");
				settings.put(Environment.USER,"root");
				settings.put(Environment.PASS,"ammappa826");
				settings.put(Environment.SHOW_SQL,"true");
				settings.put(Environment.DIALECT,"org.hibernate.dialect.MySQL5Dialect");
				settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS,"thread");
				
				
				settings.put(Environment.HBM2DDL_AUTO,"create");
				config.setProperties(settings);
				config.addAnnotatedClass(HotelManagement.class);
				ServiceRegistry sr=new StandardServiceRegistryBuilder().applySettings(config.getProperties()).build();
				
				sessionFactory = config.buildSessionFactory(sr);
			}
			catch(Exception e)
			{
				e.printStackTrace();			
			}
		}
		return sessionFactory;
	}

}
