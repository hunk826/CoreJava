package com.javaproject;

import java.util.*;
import com.javaproject.dao.*;
import com.javaproject.model.*;


import java.lang.annotation.*;

public class App 
{
    public static void main( String[] args )
    {
        
    	HotelDao hoteldao=new HotelDao();
        
        HotelManagement data1 = new HotelManagement("Rohit Shetty","rohit123@gmail.com","5343389123",324,45,3);
        HotelManagement data2 = new HotelManagement("Hritik Roshan","roshan123@gmail.com","7776536212",342,40,3);
         
        hoteldao.saveData(data1);
        hoteldao.saveData(data2);
        
//        data1.setFullName("Akshay Kumar");
//        hoteldao.updateData(data1);
        
        
//        List<HotelManagement> datad=hoteldao.getalldata();
//        datad.forEach(data3 -> System.out.println(data3.getId()));
//        
//        hoteldao.deleteData(data1);
        
    }
}
