package com.javaproject.dao;

import java.util.List;
import org.hibernate.*;
import com.javaproject.model.HotelManagement;
import com.javaproject.util.HibernateUtil;
import java.lang.annotation.*;

public class HotelDao 
{
	public void saveData(HotelManagement data)
	{
		Transaction tr=null;
		try (Session session = HibernateUtil.getSessionFactory().openSession())
		{
			tr = session.beginTransaction();
			
			session.save(data);
			
			tr.commit();
		}
		catch(Exception e)
		{
			if(tr != null)
			{
				tr.rollback();
			}
		}
	}
	public void updateData(HotelManagement data)
	{
		Transaction tr=null;
		try(Session session = HibernateUtil.getSessionFactory().openSession())
		{
			tr=session.beginTransaction();
			
			session.saveOrUpdate(data);
			
			tr.commit();
		}
		catch(Exception e)
		{
			if(tr != null)
			{
				tr.rollback();
			}
		}
	}
	public HotelManagement getRoomById(long id)
	{
		Transaction tr=null;
		HotelManagement data=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			tr=session.beginTransaction();
			
			data=session.get(HotelManagement.class,id);
			
			tr.commit();
		}
		catch(Exception e)
		{
			if(tr != null)
			{
				tr.rollback();
			}
		}
		return data;
	}
	
	
	@SuppressWarnings("unchecked")
	public List< HotelManagement > getalldata()
	{
		
		Transaction tr=null;
		List<HotelManagement> datad=null;
		try (Session session = HibernateUtil.getSessionFactory().openSession())
		{
			tr=session.beginTransaction();
			
			datad=session.createQuery("from HotelManagement").list();
					
			tr.commit();
		}
		catch(Exception e)
		{
			if(tr != null)
			{
				tr.rollback();
			}
		}
		return datad;
		
	}
	
	public void deleteData(HotelManagement id)
	{
		Transaction tr=null;
		
		try(Session session = HibernateUtil.getSessionFactory().openSession())
		{
			tr=session.beginTransaction();
			
			
			session.delete(id);
			
			tr.commit();
			
		}
		
	}
}
