package com.javaproject.dao;

import java.util.List;
import com.javaproject.model.HotelManagement;

public interface IHotelDao 
{
	void saveData(HotelManagement data);
	
	void updateData(HotelManagement data);
	
	HotelManagement getRoomById(long id);
	
	List< HotelManagement > getalldata();
	
	
	void deleteData(HotelManagement id);
}
