package com.javaproject.model;

import javax.persistence.*;

@Entity
@Table(name="Hotel")
@SecondaryTable(name="Room")
public class HotelManagement 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="FullName")
	private String FullName;
	
	@Column(name="EmailId")
	private String EmailId;
	
	@Column(name="MobileNo")
	private String MobileNo;
	
	@Column(table="Room",name="RoomNo")
	private int RoomNo;
	
	@Column(table="Room",name="Floor")
	private int Floor;
	
	@Column(table="Room",name="RoomsAvailable")
	private int RoomsAvailable;

	
	
	public HotelManagement(String fullName, String emailId, String mobileNo, int roomNo, int floor,
			int roomsAvailable) {
		this.FullName = fullName;
		this.EmailId = emailId;
		this.MobileNo = mobileNo;
		this.RoomNo = roomNo;
		this.Floor = floor;
		this.RoomsAvailable = roomsAvailable;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		this.FullName = fullName;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		this.EmailId = emailId;
	}

	public String getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.MobileNo = mobileNo;
	}

	public int getRoomNo() {
		return RoomNo;
	}

	public void setRoomNo(int roomNo) {
		this.RoomNo = roomNo;
	}

	public int getFloor() {
		return Floor;
	}

	public void setFloor(int floor) {
		this.Floor = floor;
	}

	public int getRoomsAvailable() {
		return RoomsAvailable;
	}

	public void setRoomsAvailable(int roomsAvailable) {
		this.RoomsAvailable = roomsAvailable;
	}
	
	
	
	
	
		
}
